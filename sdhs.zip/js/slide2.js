var slide=$("#slide>li");
var i=1;
setInterval(function(){
    slide.eq(i).css("left","1000px");
    slide.eq(i-1).animate({"left":"-1000px"},4500);
    slide.eq(i).animate({"left":"0"},4500)
    if(i<2)
        i++;
    else
        i=0;
    
},4500);