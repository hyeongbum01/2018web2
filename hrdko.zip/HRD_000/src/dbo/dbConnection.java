package dbo;

import java.sql.Statement ;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dbConnection {
	public Connection getConnection() throws Exception{
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "root";
		String password = "1234";
		Connection conn = null;
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn =DriverManager.getConnection(url, user, password);
			System.out.println("oracle ���� ����");
		}catch(Exception e) {
			System.out.println("oracle ���� ����");
			System.out.println(e.toString());
		}
		return conn;
		
	}
	
	public ResultSet getUserList(Connection conn) throws SQLException {

		 PreparedStatement pstmt;
		 ResultSet rs = null;
		 pstmt = conn.prepareStatement("select * from hrd_user");
		 rs = pstmt.executeQuery();
		
		return rs;
	}
}
